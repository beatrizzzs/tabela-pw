<?php
   require './dados.php';
   require './html/index.html'
   

?>