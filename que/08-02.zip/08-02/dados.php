<?php
    require './Aluno.php';

    //1
    $aluno = new Aluno('Pedrinho Maranhão',6,5,8);  
    $alunos[] = $aluno;

    //2
    $aluno = new Aluno('Geovana Neves',5,8,7);  
    $alunos[] = $aluno;

    //3
    $aluno = new Aluno('Deysiane dos Santos', 10,8,5);  
    $alunos[] = $aluno;

    //4
    $aluno = new Aluno('Leoncio Heins', 6, 4, 7);  
    $alunos[] = $aluno;

    //5
    $aluno = new Aluno('Alencris Assis', 4, 7, 9);  
    $alunos[] = $aluno;

    //6
    $aluno = new Aluno('Neide Silva', 8, 5, 9);  
    $alunos[] = $aluno;

    //7
    $aluno = new Aluno('Thais Calleriana', 10, 7, 7);  
    $alunos[] = $aluno;

    //8
    $aluno = new Aluno('Igor Antunes', 5, 6, 8);  
    $alunos[] = $aluno;

    //9
    $aluno = new Aluno('Irineu Oliveira', 5, 10, 7);  
    $alunos[] = $aluno;

    //10
    $aluno = new Aluno('Lorena Gomes', 10, 8, 9);  
    $alunos[] = $aluno;

    //11
    $aluno = new Aluno('Paula Almeida', 6.5, 10, 8.5);  
    $alunos[] = $aluno;

    //12
    $aluno = new Aluno('Yara Melissa', 9.5, 10, 5.5);  
    $alunos[] = $aluno;

    //13
    $aluno = new Aluno('Dorival Santos', 4, 8, 10);  
    $alunos[] = $aluno;

    //14
    $aluno = new Aluno('Hellen Morães', 8, 7, 6);  
    $alunos[] = $aluno;

    //15
    $aluno = new Aluno('Brenno Assunção', 7, 6, 10);  
    $alunos[] = $aluno;

    //16
    $aluno = new Aluno('Sarah Barros', 5, 6, 9);  
    $alunos[] = $aluno;

    //17
    $aluno = new Aluno('Thiago Lemos', 9, 10, 6);  
    $alunos[] = $aluno;

    //18
    $aluno = new Aluno('Cleitonval Oliveira', 7, 10, 8);  
    $alunos[] = $aluno;
    
    //19
    $aluno = new Aluno('Neílton Fontes', 6, 9, 7);  
    $alunos[] = $aluno;

    //20
    $aluno = new Aluno('Larissa Queiroga', 5.5, 6.5, 8);  
    $alunos[] = $aluno;

    //21
    $aluno = new Aluno('Vitória Ramos', 10, 4, 6);  
    $alunos[] = $aluno;

    //22
    $aluno = new Aluno('Marisa Viana', 10, 7, 10);  
    $alunos[] = $aluno;

    //23
    $aluno = new Aluno('Osvaldo Gildison', 9, 6, 8);  
    $alunos[] = $aluno;

    //24
    $aluno = new Aluno('Cirilo Cantareira', 7, 8, 10);  
    $alunos[] = $aluno;

    //25
    $aluno = new Aluno('Letícia Aguillar', 8, 9, 9);  
    $alunos[] = $aluno;

    //26
    $aluno = new Aluno('Alisson Volpi', 6, 7, 8);  
    $alunos[] = $aluno;

    //27
    $aluno = new Aluno('Bruceuaine John', 10, 6, 5);  
    $alunos[] = $aluno;

    //28
    $aluno = new Aluno('Lorenzo Santana', 8, 5, 6);  
    $alunos[] = $aluno;
    
    //29
    $aluno = new Aluno('Célia Nilton', 4, 7, 3);  
    $alunos[] = $aluno;

    //30
    $aluno = new Aluno('Amanda Estefano', 10, 5, 8);  
    $alunos[] = $aluno;

     //31
     $aluno = new Aluno('Zilda Amélia', 10, 7, 9);  
     $alunos[] = $aluno;
 
     //32
     $aluno = new Aluno('Rebecca Aderon', 7, 8.5, 6.5);  
     $alunos[] = $aluno;
 
     //33
     $aluno = new Aluno('Kátia da Silva', 8, 7, 9);  
     $alunos[] = $aluno;
 
     //34
     $aluno = new Aluno('Wesley Guimarães', 7.5, 9, 8.5);  
     $alunos[] = $aluno;
 
     //35
     $aluno = new Aluno('Hudson James', 7.5, 6, 4);  
     $alunos[] = $aluno;
 
     //36
     $aluno = new Aluno('Diana Roma', 10, 8, 9);  
     $alunos[] = $aluno;
 
     //37
     $aluno = new Aluno('Geraldone Mendes', 5, 7, 3);  
     $alunos[] = $aluno;
 
     //38
     $aluno = new Aluno('Serafina Danta', 8, 8, 10);  
     $alunos[] = $aluno;
     
     //39
     $aluno = new Aluno('Fernanda Pereira', 9, 10, 8,5);  
     $alunos[] = $aluno;
 
     //40
     $aluno = new Aluno('Enrico Lamar', 10, 9.5, 8);  
     $alunos[] = $aluno;

?>